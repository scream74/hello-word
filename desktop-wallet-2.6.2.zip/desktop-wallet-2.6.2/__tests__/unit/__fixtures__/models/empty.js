module.exports = {
  type: 'object',
  properties: {}
}
