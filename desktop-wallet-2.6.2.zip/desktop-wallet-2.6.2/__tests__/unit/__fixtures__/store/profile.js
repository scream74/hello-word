const profile1 = {
  id: 'profile1',
  networkId: 'main',
  background: 'bg',
  currency: 'usd',
  language: 'en',
  name: 'Profile 1',
  theme: 'light'
}

export default {
  profile1
}

export {
  profile1
}
