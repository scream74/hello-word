const wallet1 = {
  address: 'address 1',
  publicKey: 'public key 1'
}

const wallet2 = {
  address: 'address 2',
  publicKey: 'public key 2'
}

const wallet3 = {
  address: 'address 3',
  publicKey: 'public key 3'
}

const wallet4 = {
  address: 'address 4',
  publicKey: 'public key 4'
}

const wallet5 = {
  address: 'address 5',
  publicKey: 'public key 5'
}

const wallet6 = {
  address: 'address 6',
  publicKey: 'public key 6'
}

const wallet7 = {
  address: 'address 7',
  publicKey: 'public key 7'
}

const wallet8 = {
  address: 'address 8',
  publicKey: 'public key 8'
}

const wallet9 = {
  address: 'address 9',
  publicKey: 'public key 9'
}

const wallet10 = {
  address: 'address 10',
  publicKey: 'public key 10'
}

export default [
  wallet1,
  wallet2,
  wallet3,
  wallet4,
  wallet5,
  wallet6,
  wallet7,
  wallet8,
  wallet9,
  wallet10
]

export {
  wallet1,
  wallet2,
  wallet3,
  wallet4,
  wallet5,
  wallet6,
  wallet7,
  wallet8,
  wallet9,
  wallet10
}
