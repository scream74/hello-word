export default {

  LANGUAGES: {
    'en-US': 'Inglês',
    'es-ES': 'Espanhol',
    'pt-BR': 'Português - Brasil'
  }

}
