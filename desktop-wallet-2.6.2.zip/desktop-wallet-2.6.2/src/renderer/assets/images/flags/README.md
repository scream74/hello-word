These icons were downloaded from https://www.flaticon.com/packs/international-flags
