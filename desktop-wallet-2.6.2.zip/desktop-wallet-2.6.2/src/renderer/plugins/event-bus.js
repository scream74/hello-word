import Emittery from 'emittery'

export default new Emittery()
