export default async synchronizer => {
  // await synchronizer.$store.dispatch('delegate/load')
}
