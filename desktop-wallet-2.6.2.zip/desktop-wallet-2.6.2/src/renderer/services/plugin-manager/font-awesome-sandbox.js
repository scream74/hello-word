import * as FontAwesomeIcons from '@fortawesome/free-solid-svg-icons'
import { FontAwesomeIcon } from '@fortawesome/vue-fontawesome'

export default {
  component: FontAwesomeIcon,
  icons: FontAwesomeIcons
}
