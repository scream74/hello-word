import MenuTab from './MenuTab'
import MenuTabItem from './MenuTabItem'

export default MenuTab
export {
  MenuTab,
  MenuTabItem
}
