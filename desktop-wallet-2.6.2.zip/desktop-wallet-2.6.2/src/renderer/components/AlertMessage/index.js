import AlertMessage from './AlertMessage'

export default AlertMessage
export {
  AlertMessage
}
