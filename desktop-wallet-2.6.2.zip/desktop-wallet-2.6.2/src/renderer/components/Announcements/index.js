import AnnouncementsPost from './AnnouncementsPost'

export {
  AnnouncementsPost
}
