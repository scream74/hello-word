<template>
  <div class="TransactionTable w-full">
    <TableWrapper
      v-bind="$attrs"
      :columns="columns"
      :row-style-class="formatRow"
      :no-data-message="$t('TABLE.NO_TRANSACTIONS')"
      v-on="$listeners"
      @on-row-click="onRowClick"
      @on-sort-change="onSortChange"
    >
      <template
        slot-scope="data"
      >
        <div v-if="data.column.field === 'id' && data.row.confirmations > 0">
          <a
            class="flex items-center whitespace-no-wrap"
            href="#"
            @click.stop="network_openExplorer('transaction', data.row.id)"
          >
            <SvgIcon
              v-show="isDashboard"
              v-tooltip="{
                content: data.row.vendorField,
                classes: 'text-xs',
                trigger: 'hover',
                container: '.TransactionTable'
              }"
              :name="data.formattedRow['vendorField'] ? 'vendorfield' : 'vendorfield-empty'"
              view-box="0 0 18 18"
              class="mr-2"
            />

            <span
              v-tooltip="{
                content: data.row.id,
                classes: 'text-xs',
                trigger: 'hover',
                container: '.TransactionTable'
              }"
              class="mr-1"
            >
              {{ data.formattedRow['id'] }}
            </span>

            <SvgIcon
              name="open-external"
              view-box="0 0 12 12"
              class="text-theme-page-text-light"
            />
          </a>
        </div>

        <div
          v-else-if="data.column.field === 'amount'"
          class="flex items-center justify-end"
        >
          <span
            v-tooltip="{
              content: `${$t('TRANSACTION.AMOUNT')}: ${data.formattedRow['amount']}<br>${$t('TRANSACTION.FEE')}: ${formatAmount(data.row.fee)}`,
              html: true,
              classes: 'leading-loose',
              trigger: 'hover',
              container: '.TransactionTable',
              placement: 'left'
            }"
            class="font-bold mr-2 whitespace-no-wrap"
          >
            {{ data.row.isSender ? '-' : '+' }}
            {{ data.formattedRow['amount'] }}
          </span>
          <TransactionStatusIcon
            v-bind="data.row"
            :show-tooltip="true"
            tooltip-container=".TransactionTable"
          />
        </div>

        <div
          v-else-if="data.column.field === 'sender'"
          :class="[ isDashboard ? 'dashboard-address' : 'max-w-xxs' ]"
        >
          <WalletAddress
            :address="data.row.sender"
            :address-length="8"
            tooltip-container=".TransactionTable"
          />
        </div>

        <div
          v-else-if="data.column.field === 'recipient'"
          :class="[ isDashboard ? 'dashboard-address' : 'max-w-xxs' ]"
        >
          <WalletAddress
            :address="data.row.recipient"
            :address-length="8"
            :type="data.row.type"
            :asset="data.row.asset"
            tooltip-container=".TransactionTable"
          />
        </div>

        <span
          v-else
          :class="{ 'word-break-all': data.column.field === 'vendorField' }"
        >
          {{ data.formattedRow[data.column.field] }}
        </span>
      </template>
    </TableWrapper>

    <Portal
      v-if="selected"
      to="modal"
    >
      <TransactionShow
        :transaction="selected"
        @close="onCloseModal"
      />
    </Portal>
  </div>
</template>

<script>
import SvgIcon from '@/components/SvgIcon'
import truncateMiddle from '@/filters/truncate-middle'
import TransactionShow from './TransactionShow'
import TransactionStatusIcon from './TransactionStatusIcon'
import WalletAddress from '@/components/Wallet/WalletAddress'
import TableWrapper from '@/components/utils/TableWrapper'

export default {
  name: 'TransactionTable',

  components: {
    SvgIcon,
    TableWrapper,
    TransactionShow,
    TransactionStatusIcon,
    WalletAddress
  },

  props: {
    hasShortId: {
      type: Boolean,
      required: false,
      default: false
    },
    isDashboard: {
      type: Boolean,
      required: false,
      default: false
    }
  },

  data: () => ({
    selected: null
  }),

  computed: {
    columns () {
      const vendorFieldClass = [
        'hidden', 'w-1/4'
      ]
      if (this.hasShortId && !this.isDashboard) {
        vendorFieldClass.push('xxl:table-cell')
      } else if (!this.isDashboard) {
        vendorFieldClass.push('xl:table-cell')
      }

      return [
        {
          label: this.$t('TRANSACTION.ID'),
          field: 'id',
          formatFn: this.formatTransactionId
        },
        {
          label: this.$t('COMMON.DATE'),
          field: 'timestamp',
          type: 'date',
          formatFn: this.formatDate,
          tdClass: 'text-center',
          thClass: 'text-center'
        },
        {
          label: this.$t('TRANSACTION.SENDER'),
          field: 'sender'
        },
        {
          label: this.$t('TRANSACTION.RECIPIENT'),
          field: 'recipient'
        },
        {
          label: this.$t('TRANSACTION.VENDOR_FIELD'),
          field: 'vendorField',
          formatFn: this.formatSmartbridge,
          tdClass: vendorFieldClass.join(' '),
          thClass: vendorFieldClass.join(' ')
        },
        {
          label: this.$t('TRANSACTION.AMOUNT'),
          type: 'number',
          field: 'amount',
          formatFn: this.formatAmount,
          tdClass: 'text-right',
          thClass: 'text-right'
        }
      ]
    }
  },

  methods: {
    formatDate (value) {
      return this.formatter_date(value)
    },

    formatAddress (value) {
      return this.wallet_formatAddress(value, 10)
    },

    formatTransactionId (value) {
      return this.hasShortId ? truncateMiddle(value, 6) : truncateMiddle(value, 10)
    },

    formatAmount (value) {
      return this.formatter_networkCurrency(value)
    },

    formatSmartbridge (value) {
      if (value.length > 43) {
        return `${value.slice(0, 40)}...`
      }
      return value
    },

    formatRow (row) {
      const classes = [
        row.confirmations === 0 ? 'unconfirmed' : 'confirmed'
      ]

      if (row.isExpired) {
        classes.push('expired')
      }

      return classes.join(' ')
    },

    openTransactions (id) {
      this.network_openExplorer('transaction', id)
    },

    onSortChange ({ columnIndex, sortType }) {
      if (this.columns[columnIndex]) {
        const columnName = this.columns[columnIndex].field
        this.$emit('on-sort-change', { columnName, sortType })
      }
    },

    onRowClick ({ row }) {
      this.selected = row
    },

    onCloseModal () {
      this.selected = null
    }
  }
}
</script>

<style lang="postcss">
.TransactionTable tr.unconfirmed {
  @apply opacity-50 text-theme-page-text;
}
.TransactionTable tr.unconfirmed .Transaction__confirmations {
  @apply text-theme-page-text bg-theme-page-instructions-background;
}
.TransactionTable tr.expired {
  @apply line-through;
}
.TransactionTable td .dashboard-address {
  width: 100px;
}
</style>
