import WalletExchange from './WalletExchange'

export default WalletExchange
export {
  WalletExchange
}
