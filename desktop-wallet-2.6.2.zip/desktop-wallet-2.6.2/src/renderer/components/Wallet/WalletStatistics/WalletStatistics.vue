<template>
  <div class="bg-white rounded-b-lg p-5">
    TODO
  </div>
</template>

<script>
export default {
  name: 'WalletStatistics',

  components: {
  },

  props: {
  }
}
</script>
