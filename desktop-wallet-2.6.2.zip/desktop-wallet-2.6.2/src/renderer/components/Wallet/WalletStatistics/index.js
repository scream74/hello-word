import WalletStatistics from './WalletStatistics'

export default WalletStatistics

export {
  WalletStatistics
}
