import WalletDetails from './WalletDetails'

export default WalletDetails

export {
  WalletDetails
}
