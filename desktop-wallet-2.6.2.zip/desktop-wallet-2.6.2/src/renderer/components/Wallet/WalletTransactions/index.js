import WalletTransactions from './WalletTransactions'

export default WalletTransactions

export {
  WalletTransactions
}
