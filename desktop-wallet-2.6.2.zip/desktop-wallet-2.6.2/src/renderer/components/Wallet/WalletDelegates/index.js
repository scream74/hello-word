import WalletDelegates from './WalletDelegates'

export default WalletDelegates

export {
  WalletDelegates
}
