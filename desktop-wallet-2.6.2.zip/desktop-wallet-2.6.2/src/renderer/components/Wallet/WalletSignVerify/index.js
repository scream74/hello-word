import WalletSignVerify from './WalletSignVerify'

export default WalletSignVerify

export {
  WalletSignVerify
}
