import WalletSidebar from './WalletSidebar'

export default WalletSidebar

export {
  WalletSidebar
}
