import WalletHeading from './WalletHeading'
import WalletHeadingInfo from './WalletHeadingInfo'
import WalletHeadingMenuLedger from './WalletHeadingMenuLedger'

export default WalletHeading

export {
  WalletHeading,
  WalletHeadingInfo,
  WalletHeadingMenuLedger
}
