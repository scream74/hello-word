import SvgIcon from './SvgIcon'

export default SvgIcon
export {
  SvgIcon
}
