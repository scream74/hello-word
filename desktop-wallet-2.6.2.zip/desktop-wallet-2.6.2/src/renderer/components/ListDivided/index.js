import ListDivided from './ListDivided'
import ListDividedItem from './ListDividedItem'

export default ListDivided
export {
  ListDivided,
  ListDividedItem
}
