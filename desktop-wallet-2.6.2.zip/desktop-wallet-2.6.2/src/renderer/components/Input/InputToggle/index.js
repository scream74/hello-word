import InputToggle from './InputToggle'
import InputToggleChoice from './InputToggleChoice'

export default InputToggle
export {
  InputToggle,
  InputToggleChoice
}
