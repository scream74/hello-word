import ContactRenameModal from './ContactRenameModal'
import ContactRemovalConfirmation from './ContactRemovalConfirmation'

export {
  ContactRenameModal,
  ContactRemovalConfirmation
}
