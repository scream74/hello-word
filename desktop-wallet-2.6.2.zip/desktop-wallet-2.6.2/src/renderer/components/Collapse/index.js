import Collapse from './Collapse'
import CollapseAccordion from './CollapseAccordion'

export default Collapse
export {
  Collapse,
  CollapseAccordion
}
